# NightCrate seed data audit — sensor.csv findings

**For:** Fred. Not part of any Claude Code handoff.
**Companion:** `nightcrate-seed-audit-handoff-sensors.md` carries the single correction CC applies.
**Coverage:** all 41 rows checked by internal consistency; targeted source verification on every row those checks flagged.

Note: `sensor.sony.imx662_color`, `sensor.sony.imx662_mono` and `sensor.sony.imx411_mono` were corrected in batch 1 and appear in `nightcrate-seed-audit-handoff.md`, not here.

---

## Confirmed correction (1 row, 6 fields)

```
file       | seed_key                 | column                | current | correct | source URL
-----------|--------------------------|-----------------------|---------|---------|------------
sensor.csv | sensor.sony.imx676_color | pixel_size_um         | 3.76    | 2.0     | https://www.zwoastro.com/product/asi676/
sensor.csv | sensor.sony.imx676_color | sensor_width_mm       | 13.35   | 7.10    | (same)
sensor.csv | sensor.sony.imx676_color | sensor_height_mm      | 13.35   | 7.10    | (same)
sensor.csv | sensor.sony.imx676_color | full_well_capacity_ke | 50.0    | 10.55   | (same)
sensor.csv | sensor.sony.imx676_color | read_noise_e          | 1.1     | 0.56    | (same)
sensor.csv | sensor.sony.imx676_color | peak_qe_pct           | 85.0    | 83.0    | (same)
```

**This is the most serious error found in the audit so far.** The row was filled with IMX571/IMX455-family values rather than IMX676 values. The existing note admits it in writing — it describes "3.76um pixels (same as IMX571/455)" and a "1 inch" format, neither of which is true of the IMX676. ZWO's ASI676MC manual gives Type 1/1.6, 10.04mm diagonal, 2um pixels, 7.104 x 7.104mm imaging area.

The consequence is a plate-scale error that inflated the computed field by 88%: at 250mm the row produced a 184 arcmin square field against a true 98, and at 1000mm 46 against 24. Two cameras reference it.

**Method lesson.** This row passed the dimensions-equal-resolution-times-pixel-size check cleanly, because all four fields were mutually consistent — consistently wrong together. Arithmetic catches one mistyped field; it cannot catch a row filled coherently from the wrong sensor family. The checks that did catch it were diagonal-versus-optical-format plausibility and a read of the note itself.

---

## Suspects — need a source before changing (4)

| seed_key | column | seeded | issue |
|---|---|---|---|
| `sensor.sony.imx174_color` | peak_qe_pct | 77.0 | Identical to the mono row. See below. |
| `sensor.sony.imx462_color` | peak_qe_pct | 91.0 | Identical to the mono row. See below. |
| `sensor.sony.imx662_color` | peak_qe_pct | 91.0 | Identical to the mono row. See below. |
| `camera.player_one.apollo_mini` | sensor_seed_key | `sensor.sony.imx676_color` | The Apollo-M Mini is a **monochrome** camera mapped to a **colour** sensor row. The only mono/colour naming mismatch in all 112 camera rows. Player One's Apollo-M MINI is generally documented as IMX432 mono, which has no row in `sensor.csv` — so resolving this needs a new sensor row, which falls under the separate add-models work rather than this audit. |

### The identical-QE flag

A colour sensor has a Bayer matrix over the same silicon, so its peak QE is always below the mono version. Across the 14 mono/colour pairs the seed reflects this consistently — deltas of +4 to +15 points — except for three pairs where the two values are exactly equal:

| pair | mono | colour | delta |
|---|---|---|---|
| IMX174 | 77.0 | 77.0 | 0.0 |
| IMX462 | 91.0 | 91.0 | 0.0 |
| IMX662 | 91.0 | 91.0 | 0.0 |

**Caveat worth taking seriously before "fixing" these.** IMX462 and IMX662 are STARVIS sensors marketed on near-infrared sensitivity, and the widely quoted 91% figure for them is the **NIR peak**, not the visible peak. If the seed is recording peak QE wherever it falls in the spectrum, a colour row legitimately matching mono in the NIR is defensible, because the Bayer dyes are largely transparent there. The IMX174 pair has no such excuse — it is not an NIR-marketed part.

So this is really two questions: whether `peak_qe_pct` means visible peak or spectral peak (a schema/semantics decision), and only then whether these three values are wrong. I have not changed them.

---

## Verified correct

- **All 14 mono/colour pairs agree** on every field that must match between them: pixel size, both resolutions, both dimensions, ADC bit depth and dual-gain flag. Zero discrepancies.
- **`sensor.omnivision.os08b10_color`** — I suspected the 2.9um pixel size and checked it. It is correct. OmniVision's own page gives the OS08B10 as a 1/1.25" 3840 x 2160 part, and 2.9um yields a 12.78mm diagonal matching that format. My suspicion came from confusing it with the OV08B10, an unrelated 1/4" 1.12um smartphone sensor. The seeded row is right and should not be touched.
- **Diagonal-versus-format plausibility across all 41 rows** — every row except IMX676 lands on a sensible optical format for its stated dimensions.
- **ADC bit depths** — 12-bit (27 rows), 16-bit (7), 14-bit (6) are all standard. One row uses 10-bit, `sensor.sony.imx615_color`, which is unusual but that row is a gap case (see below) rather than a verified value.

---

## Gaps — recorded, not filled

**Four rows carry no `full_well_capacity_ke`, `read_noise_e` or `peak_qe_pct`:**

- `sensor.sony.imx415_color`
- `sensor.sony.imx347_color`
- `sensor.sony.imx615_color`
- `sensor.omnivision.os08b10_color`

All four are smart-telescope sensors rather than astronomy-camera parts, and the manufacturers publish video-security specifications rather than the astronomical figures the schema wants. Leaving them blank is correct.

For the OS08B10 specifically there is an independent characterisation by Cuiv (measured in SharpCap on a Seestar S50 Pro) covering QE, read noise and full well. It is measured rather than published, and its own author notes the QE curve is a proxy assumed from a paper rather than measured on the unit. If you ever want these fields populated, that is the best source available — but it is a different evidential standard from the rest of the file and should be marked as such if used.

**`source_url` is blank on 38 of 41 rows.** Unchanged from the first pass.

---

## Not done

Read noise, full well and peak QE were verified only where an internal-consistency check flagged the row. The remaining ~35 rows carry plausible values that I have not individually sourced. Same constraint as mount weights: these live in manufacturer spec tables that search summarises poorly, and for sensors there is an additional complication — read noise and full well are gain-dependent, so a single seeded number is already an approximation of a curve, and "correct" depends on which gain point the schema intends.
