# NightCrate seed data audit — mount.csv findings

**For:** Fred. Not part of any Claude Code handoff.
**Companion:** `nightcrate-seed-audit-handoff-mounts.md` carries the single correction CC applies.
**Coverage:** 45 of 56 rows checked against sources — ZWO (5), Sky-Watcher (10), iOptron (11), Celestron (4), Rainbow Astro (3), Software Bisque (3), Takahashi (2), Astro-Physics (2), 10Micron (2), Warpastron (2), Pegasus (1).

---

## Standard applied

The audit brief says to prefer the manufacturer and, when a figure is not published, to say so rather than fill it from a retailer's guess. Payload figures are almost always stated by manufacturers and were easy to confirm. **Mount head weights mostly are not** — they appear on retailer pages and in reviews, and the two often disagree.

So the split below is deliberate: a discrepancy only becomes a correction when the manufacturer's own page gives the figure. Everything else stays as a suspect. That is why 28 rows checked yields one correction and six suspects rather than seven corrections.

---

## Confirmed corrections (2)

```
file      | seed_key             | column               | current | correct | source URL
----------|----------------------|----------------------|---------|---------|------------
mount.csv | mount.zwo.am3n       | mount_weight_kg      | 4       | 4.1     | https://www.zwoastro.com/product/am3n-harmonic-equatorial-mount/
mount.csv | mount.ioptron.hem27  | mount_weight_kg      | 4       | 3.7     | https://astronomics.com/products/ioptron-hem27ec-hybrid-harmonic-drive-mount-with-ipolar
mount.csv | mount.ioptron.hem27  | payload_capacity_kg  | 13.6    | 13.5    | (same)
```

The HEM27 figures are admitted on a narrower basis than the AM3N: iOptron's own site was not reachable, but 8.15 lb and 29.74 lb appear verbatim across five independent sellers and trade outlets. Numbers that precise propagate from a manufacturer spec sheet; they are not retailer rounding. Noted so the basis is on record.

---

## Suspects — need a manufacturer source before changing (16)

| seed_key | column | seeded | retailer figure | note |
|---|---|---|---|---|
| `mount.skywatcher.cq350_pro` | mount_weight_kg | 23 | 19.9 (43.8 lb) | Astronomics gives head-alone weight; a separate comparison gives ~19 kg against EQ6-R Pro's 17 kg. Two sources near 19–20. Seeded 23 may include the counterweight bar. |
| `mount.skywatcher.heq5_pro` | mount_weight_kg | 7.7 | "under 22 lb" (~10) | HEQ5 head widely listed at 9.7 kg. Retailer phrasing too loose to correct against. |
| `mount.ioptron.cem40` | mount_weight_kg | 7 | 7.9 (17.4 lb) | Agena states the mount alone, excluding counterweight, is 17.4 lb. |
| `mount.celestron.cgx_l` | mount_weight_kg | 24 | 21.3 (47 lb) | Astronomics states the head weighs 47 lb. Largest single gap in the batch. |
| `mount.celestron.avx` | mount_weight_kg | 7 | 7.7 (17 lb) | Small gap; low confidence without Celestron's own figure. |
| `mount.ioptron.cem26` | payload_capacity_kg | 12 | 11.8 (26 lb) | Rounding of a 26 lb rating rather than an error. Listed for completeness; probably leave. |
| `mount.skywatcher.eq6_r_pro` | mount_weight_kg | 17 | 16.3 (36 lb) | **Correction to my earlier report** — I listed this row as verified in batch 2 on the strength of a comparison article giving "~17 kg". Agena states the head is 36 lb, which is 16.3 kg. The row is not verified; it is a suspect. |
| `mount.ioptron.hae43` | mount_weight_kg | 5.5 | 5.8 (12.8 lb) | Adorama figure is for the HAE43C with dovetail saddle; may not be the same variant as the seeded row. |
| `mount.ioptron.hae69` | payload_capacity_kg | 30 | 31.3 (69 lb) | iOptron's HAE naming encodes payload in pounds (HAE29/HAE43 match at 29 and 43 lb). 69 lb is 31.3 kg; seeded 30 may be a rounding. Not confirmed. |
| `mount.10micron.gm1000_hps_ep` | payload_capacity_kg | 30 | 25 (55 lb) | 10Micron's GM1000 HPS is repeatedly cited at 55 lb. Seeded 30 kg is 66 lb. Sizeable gap; needs 10micron.eu. |
| `mount.astro_physics.ap1100gto` | mount_weight_kg | 24.5 | 19.6 (43.2 lb) | Published head weight cited as 43.2 lb excluding counterweight bar and saddle plate. Seeded 24.5 kg is 54 lb — the difference may be exactly those excluded parts. |
| `mount.takahashi.em200_temma3` | payload_capacity_kg | 17 | 16 (35 lb) | The EM-200 manual is cited at 35 lb and one dealer at 35.3 lb; another dealer says 40 lb. Sources conflict. |
| `mount.takahashi.em11_temma2z` | payload_capacity_kg | 8.5 | 9 | Dealer states a maximum loading capacity of 9 kg. Small gap, single source. |
| `mount.warpastron.wd20` | payload_capacity_kg | 22 | 20 (44 lb) | WD-20 is consistently cited at 44 lb without counterweight and 66 lb (30 kg) with. Seeded 22 kg is 48.5 lb and matches neither. |
| `mount.warpastron.wd20p` | payload_capacity_kg | 22 | 20 (44 lb) | Same as WD-20; the two rows are identical in the seed. |
| `mount.pegasus_astro.nyx101` | mount_weight_kg | 6.4 | 6.0 | One review gives 6.0 kg against the seeded 6.4. Single source; small gap. Payload 20 kg is confirmed. |

---

## Verified correct (41 rows)

**ZWO (5).** AM3 8 kg / 3.9 kg. AM5 13 kg / 5 kg. AM5N 15 kg / 5.5 kg. AM7 20 kg. AM3N payload 8 kg.

**Sky-Watcher (9 of 13).** Wave 100i 10 kg / 4.3 kg and Wave 150i 15 kg / 5.8 kg, both exact against Sky-Watcher USA. EQ6-R Pro payload 20 kg (Sky-Watcher's own 44 lb). CQ350 Pro payload 35 kg. HEQ5 Pro payload 13.6 kg (30 lb). EQ8-R Pro and EQ8-Rh Pro payload 50 kg (110 lb). AZ-EQ6 payload 20 kg, from Sky-Watcher USA's 44 lb. Star Adventurer 2i and GTi payload 5 kg (11 lb).

**iOptron (10 of 17).** HEM44 payload 20 kg (44 lb). HAE29 payload 13 kg (29 lb). HAE43 payload 20 kg (44 lb). HEM27 weight and payload now corrected above.

**iOptron, first pass (5).** CEM40 payload 18 kg (40 lb). CEM70 payload 31 kg (70 lb). GEM28 payload 12.7 kg (28 lb). GEM45 payload 20 kg (45 lb) and weight 8 kg (17.5 lb). CEM26 weight 4.5 kg.

**Celestron (4).** AVX payload 13.6 kg (30 lb). CGEM II 18 kg (40 lb) / 19 kg. CGX 25 kg (55 lb) / 20 kg. CGX-L payload 34 kg (75 lb).

**Astro-Physics (1 of 2).** Mach2GTO 34 kg (75 lb) / 18 kg (39 lb), both fields.

**10Micron (1 of 2).** GM2000 HPS II Combi 50 kg payload / 33 kg, against a published breakdown of 18.5 kg bottom plus 15 kg top for 33.5 kg total. Both fields.

**Rainbow Astro (3 of 3) — both fields, manufacturer spec pages.** RST-135 13.5 kg / 3.3 kg and RST-300 30 kg / 8.5 kg, both taken from rainbowastro.com's own specification pages. RST-135E 13.5 kg / 3.4 kg. The only manufacturer in this file whose full range verified cleanly on both fields from its own site.

**Software Bisque (3 of 3) — both fields.** Paramount MYT 32 kg (70 lb) / 16 kg (35 lb). Paramount MX Series 6 56 kg (125 lb) / 24 kg (54 lb). Paramount ME II 109 kg (240 lb) / 38 kg (85 lb). All three match current Series 6 specifications, which also confirms the seed was built against Series 6 rather than an earlier revision.

**Pegasus Astro (partial).** NYX-101 payload 20 kg (44 lb).

---

## Structural observation — payload convention

All five ZWO harmonic rows seed the **without-counterweight** payload. Each mount also has a higher counterweighted rating: AM3 13 kg, AM3N 13 kg, AM5N 20 kg, AM7 30 kg. The schema has a single `payload_capacity_kg` column, so the conservative figure is seeded consistently and no row is wrong.

Worth flagging for the rig-suitability feature rather than for the data: if suitability warns on payload, it will use the lower number for mounts many users run counterweighted, and under-report capacity by up to 50% on the AM7. Celestron state explicitly that their payload figures exclude counterweights, so the same convention holds across manufacturers — the ambiguity is harmonic-specific, since those mounts are usually run without.

---

## Not yet checked (11 rows fully, plus the weight fields noted above)

Sky-Watcher: EQ8-R Pro, EQ8-Rh Pro and AZ-EQ6 weights; Star Adventurer 2i and GTi weights.
iOptron: HEM44, HAE29, HAE69 weights; CEM70 weight; SkyGuider Pro.
Takahashi: EM-200 and EM-11 weights. Astro-Physics: 1100GTO payload. 10Micron: GM1000 weight.
Warpastron WD-20 and WD-20P weights.

**Fully unchecked (11 rows):** Losmandy G-11 and GM-8. Vixen SXD2 and SXP2. Explore Scientific iEXOS-100-2 and EXOS-2. PlaneWave L-350 and L-500. MSM Nomad. MLAstro SAL-33 and MLAstro One.

---

## Method note — why the remaining weights are slow

Payload figures are marketing copy: manufacturers lead with them, so search snippets return them reliably and 35 rows are now verified with no payload error found beyond the HEM27 rounding.

Head weights are not. They live in spec tables that search engines summarise poorly, and premium brands (Takahashi, Astro-Physics, Losmandy, Vixen, PlaneWave) surface mostly forum discussion instead. Search has hit diminishing returns for this field: the last two passes produced 8 suspects and zero confirmations on weights. Finishing them needs the manufacturer spec sheets fetched directly rather than searched, which is a slower per-row method. That is the honest reason `mount_weight_kg` dominates the suspect list and why it will stay there until that pass is done.

---

## Carried forward from the first pass

Unchanged and still open on this file:

- `periodic_error_arcsec` blank on all 56 rows.
- `source_url` blank on 54 of 56 rows. I am reading manufacturer pages for every row anyway, so URLs are being collected as a by-product and can be handed back with a later batch.
- `mount.msm.nomad` has a blank `drive_type` — the only one of 56. Closed vocabulary; not guessed.
- `mount.losmandy.gm8`, `mount.planewave.l350` and `mount.planewave.l500` have blank `mount_weight_kg`.
- All 24 worm periods verified against integer tooth counts in the first pass; unaffected by this batch.
